import flask

from application import api
from data import Consts
from models import db, logger


def create_app():
    app = flask.Flask("app")
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///prebotfb.db"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    app.register_blueprint(api)

    db.init_app(app)
    with app.app_context():
        db.create_all()

    return app

if __name__ == '__main__':
    logger.info("Firin up FbBot using verify token [{verify_token}].".format(verify_token=Consts.VERIFY_TOKEN))
    app = create_app()
    app.run(debug=True)