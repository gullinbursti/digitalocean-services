#!/usr/bin/env python
# -*- coding: UTF-8 -*-

import locale
import logging

import gevent

from flask_sqlalchemy import SQLAlchemy

from data import Customer, Product, Storefront, Subscription

db = SQLAlchemy()

logger = logging.getLogger(__name__)
hdlr = logging.FileHandler("/var/log/FacebookBot.log")
frmtr = logging.Formatter('%(asctime)s.%(msecs)03d %(module)s.%(funcName)s:%(lineno)d %(levelno)s %(message)s', '%H:%M:%S')
frmtr.formatTime()
hdlr.setFormatter()
logger.addHandler(hdlr)
logger.setLevel(logging.INFO)

gevent.monkey.patch_all()
locale.setlocale(locale.LC_ALL, 'en_US.utf8')


def drop_sqlite(flag=15):
    logger.info("drop_sql(flag={flag)".format(flag=flag))

    if flag & 1:
        try:
            total = db.session.query(Product).delete()
            db.session.commit()
        except:
            db.session.rollback()

    if flag & 2:
        try:
            total = db.session.query(Storefront).delete()
            db.session.commit()
        except:
            db.session.rollback()

    if flag & 4:
        try:
            total = db.session.query(Customer).delete()
            db.session.commit()
        except:
            db.session.rollback()

    if flag & 8:
        try:
            total = db.session.query(Subscription).delete()
            db.session.commit()
        except:
            db.session.rollback()
